<?php

include 'config.php';
session_start();
$user_id = $_SESSION['user_id'];

if(isset($_POST['view'])){

   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $password = mysqli_real_escape_string($conn, $_POST['password']);
   $age = mysqli_real_escape_string($conn, $_POST['age']);
   $contact = mysqli_real_escape_string($conn, $_POST['contact']);
  
   

   $image = $_FILES['image']['name'];
   $image_size = $_FILES['image']['size'];
   $image_tmp_name = $_FILES['image']['tmp_name'];
  
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>view profile</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
<style>
    img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}   
    </style>

<img src="images/small_GUVI_1_c02a18fad7.png" alt="guvi image" width="30%" >
   
<div class="update-profile">

   <?php
      $select = mysqli_query($conn, "SELECT * FROM `user_form` WHERE id = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select) > 0){
         $fetch = mysqli_fetch_assoc($select);
      }
   ?>
  
   <form action="" method="post" enctype="multipart/form-data">
   <h3>PERSONAL INFORMATION</h3>
      <?php
         if($fetch['image'] == ''){
            echo '<img src="images/default-avatar.png">';
         }else{
            echo '<img src="uploaded_img/'.$fetch['image'].'">';
         }
         if(isset($message)){
            foreach($message as $message){
               echo '<div class="message">'.$message.'</div>';
            }
         }
      ?>
      
      <div class="flex">
         <div class="inputBox">
            <span>username :</span>
            <input type="text" name="name" value="<?php echo $fetch['name']; ?>" class="box">
            <span>your email :</span>
            <input type="email" name="email" value="<?php echo $fetch['email']; ?>" class="box">
           
            
         </div>
         <div class="inputBox">
         <span>age :</span>
            <input type="number" name="age" value="<?php echo $fetch['age']; ?>" class="box">
            <span>contact :</span>
            <input type="contact" name="contact" value="<?php echo $fetch['contact']; ?>" class="box">
               </div>
      </div>
      <a href="home.php" class="delete-btn">go back</a>
   </form>

</div>

</body>
</html>